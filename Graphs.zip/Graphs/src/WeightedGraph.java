import java.util.*;

public class WeightedGraph<T> {
    private final boolean undirected;
    private final List<Vertex<T>> vertices = new ArrayList<>();

    WeightedGraph(boolean undirected) {
        this.undirected = undirected;
    }

    public void addVertex(Vertex<T> vertex) {
        vertices.add(vertex);
    }

    public void addEdge(Vertex<T> destinationFrom, Vertex<T> destinationTo, double weight) {
        if (!hasVertex(destinationFrom)) {
            addVertex(destinationFrom);
        }

        if (!hasVertex(destinationTo)) {
            addVertex(destinationTo);
        }

        if (hasEdge(destinationFrom, destinationTo) || destinationFrom.equals(destinationTo)) {
            return;
        }

        if (undirected) {
            for (Vertex<T> vertex : vertices) {
                if (vertex.equals(destinationFrom) && !hasEdge(destinationFrom, destinationTo)) {
                    vertex.addAdjacentVertex(destinationTo, weight);
                }

                if (vertex.equals(destinationTo) && !hasEdge(destinationTo, destinationFrom)) {
                    vertex.addAdjacentVertex(destinationFrom, weight);
                }
            }
        } else {
            for (Vertex<T> vertex : vertices) {
                if (vertex.equals(destinationFrom) && !hasEdge(destinationFrom, destinationTo)) {
                    vertex.addAdjacentVertex(destinationTo, weight);
                }
            }
        }

    }

    public boolean hasVertex(Vertex<T> vertex) {
        for (Vertex<T> element : vertices) {
            if (element.getData().equals(vertex.getData())) {
                return true;
            }
        }

        return false;
    }

    public boolean hasEdge(Vertex<T> destinationFrom, Vertex<T> destinationTo) {
        if (!hasVertex(destinationFrom)) {
            return false;
        }

        for (Vertex<T> element : vertices) {
            if (element.getData().equals(destinationFrom) && element.getAdjacentVertices() != null) {
                for (Vertex<T> elementVertex : element.getAdjacentVertices().keySet()) {
                    if (elementVertex.getData().equals(destinationTo)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public int getEdgesCount() {
        int count = 0;

        for (Vertex<T> vertex : vertices) {
            count += vertex.getAdjacentVertices().size();
        }

        if (undirected) {
            count /= 2;
        }

        return count;
    }

    public int getVerticesCount() {
        return vertices.size();
    }

    public List<Vertex<T>> adjacencyList(Vertex<T> vertex) {
        if (!hasVertex(vertex)) {
            return null;
        }

        List<Vertex<T>> vertices = new LinkedList<>();

        for (Vertex<T> element : this.vertices) {
            if (element.getData().equals(vertex.getData())) {
                vertices.addAll(element.getAdjacentVertices().keySet());
                break;
            }
        }

        return vertices;
    }

    public Map<Vertex<T>, Double> getEdges(Vertex<T> vertex) {
        if (!hasVertex(vertex)) {
            return null;
        }

        for (Vertex<T> element : vertices) {
            if (element.getData().equals(vertex.getData())) {
                return element.getAdjacentVertices();
            }
        }

        return null;
    }

    public List<Vertex<T>> getVertices() {
        return vertices;
    }
}

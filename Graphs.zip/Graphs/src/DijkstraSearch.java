import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class DijkstraSearch<T> extends Search<T> {
    private final Set<Vertex<T>> unsettledNodes;
    private final Map<Vertex<T>, Double> distances;
    private final WeightedGraph<T> graph;

    public DijkstraSearch(WeightedGraph<T> graph, Vertex<T> source) {
        super(source);
        unsettledNodes = new HashSet<>();
        distances = new HashMap<>();
        this.graph = graph;
        dijkstra();
    }

    public void dijkstra() {
        distances.put(source, 0D);
        unsettledNodes.add(source);

        while (unsettledNodes.size() > 0) {
            Vertex<T> node = getVertexWithMinimumWeight(unsettledNodes);
            marked.add(node);
            unsettledNodes.remove(node);

            for (Vertex<T> vertex : graph.adjacencyList(node)) {
                if (getShortestDistance(vertex) > getShortestDistance(node) + getDistance(node, vertex)) {
                    distances.put(vertex, getShortestDistance(node)
                            + getDistance(node, vertex));
                    edgeTo.put(vertex, node);
                    unsettledNodes.add(vertex);
                }
            }
        }
    }

    private double getDistance(Vertex<T> node, Vertex<T> target) {
        for (Vertex<T> vertex : graph.getEdges(node).keySet()) {
            if (vertex.equals(target)) {
                return graph.getEdges(node).get(vertex);
            }
        }

        throw new RuntimeException("Not found!");
    }

    private Vertex<T> getVertexWithMinimumWeight(Set<Vertex<T>> vertices) {
        Vertex<T> minimum = null;

        for (Vertex<T> vertex : vertices) {
            if (minimum == null)
                minimum = vertex;
            else {
                if (getShortestDistance(vertex) < getShortestDistance(minimum)) {
                    minimum = vertex;
                }
            }
        }

        return minimum;
    }

    private double getShortestDistance(Vertex<T> destination) {
        Double d = distances.get(destination);
        return (d == null ? Double.MAX_VALUE : d);
    }
}

import java.util.LinkedList;
import java.util.Queue;

public class BreadthFirstSearch<T> extends Search<T> {
    public BreadthFirstSearch(WeightedGraph<T> graph, Vertex<T> source) {
        super(source);
        bfs(graph, source);
    }

    private void bfs(WeightedGraph<T> graph, Vertex<T> current)
    {
        Queue<Vertex<T>> queue = new LinkedList<>();
        marked.add(current);
        queue.add(current);

        while (!queue.isEmpty()) {
            Vertex<T> vertex = queue.remove();

            for (Vertex<T> adjacent : graph.adjacencyList(vertex)) {
                if (!marked.contains(adjacent)) {
                    marked.add(adjacent);
                    edgeTo.put(adjacent, vertex);
                    queue.add(adjacent);
                }
            }
        }
    }
}
